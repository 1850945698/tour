package tour.user.collcet;

import tour.entity.Tourinformation;

public class CollectItem {
	private Tourinformation tif;
	private int count;
//	public User getUser() {
//		return user;
//	}
//	public void setUser(User user) {
//		this.user = user;
//	}
//	public int getCount() {
//		return count;
//	}
//	public void setCount(int count) {
//		this.count = count;
//	}
	public Tourinformation getTif() {
		return tif;
	}
	public void setTif(Tourinformation tif) {
		this.tif = tif;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
}
